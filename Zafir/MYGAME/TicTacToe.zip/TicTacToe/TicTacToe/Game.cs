﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Game
    {
        public static int noOfTurns = 0;
        
        int location = 0;
        
        public static bool win = false;
        
        bool player1 = false;
        bool player2 = false;
            
        public string[,] position = new string[3, 3];

        string playerName1;
        string playerName2;
        public void Start()
        {
            Console.Write("Player1, Enter Your Name : ");
            playerName1 = Console.ReadLine();
            Console.WriteLine();

            Console.Write("Player2, Enter Your Name : ");
            playerName2 = Console.ReadLine();
            Console.WriteLine();

            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    position[row, col] = "_";
                }
            }

            for (int i = 0; i < 9; i++)
            {
                ++noOfTurns;

                if (noOfTurns % 2 == 1)
                {
                    player1 = true;
                    player2 = false;
                }

                if (noOfTurns % 2 == 0)
                {
                    player2 = true;
                    player1 = false;
                }

                if (player1)
                {
                    Console.Write(playerName1 + " Please Enter Location : ");
                    location = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine();

                    checkLocation("X");
                }
                else if (player2)
                {
                    Console.Write(playerName2 + " Please Enter Location : ");
                    location = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine();

                    checkLocation("O");
                }

                printGame();

                if (checkIfWin() == true)
                {
                    if (player1)
                    {
                        Console.WriteLine(playerName1 + " WON :) \n");
                    }
                    if (player2)
                    {
                        Console.WriteLine(playerName2 + " WON :) \n");
                    }

                    break;
                }
            }

        }

        public bool checkIfWin()
        {
            if (position[0, 0] == position[0, 1] && position[0, 1] == position[0, 2] && position[0, 1] != "_")
            {
                return win = true;
            }
            else if (position[1, 0] == position[1, 1] && position[1, 1] == position[1, 2] && position[1, 1] != "_")
            {
                return win = true;
            }
            else if (position[2, 0] == position[2, 1] && position[2, 1] == position[2, 2] && position[2, 1] != "_")
            {
                return win = true;
            }
            else if (position[0, 0] == position[1, 0] && position[1, 0] == position[2, 0] && position[1, 0] != "_")
            {
                return win = true;
            }
            else if (position[0, 1] == position[1, 1] && position[1, 1] == position[2, 1] && position[1, 1] != "_")
            {
                return win = true;
            }
            else if (position[0, 2] == position[1, 2] && position[1, 2] == position[2, 2] && position[1, 2] != "_")
            {
                return win = true;
            }
            else if (position[0, 2] == position[1, 1] && position[1, 1] == position[2, 0] && position[1, 1] != "_")
            {
                return win = true;
            }
            else if (position[0, 0] == position[1, 1] && position[1, 1] == position[2, 2] && position[1, 1] != "_")
            {
                return win = true;
            }
            else
            {
                return win = false;
            }
        }

        public void checkLocation(string xo) 
        {
            if (location == 1)
            {
                position[0, 0] = xo;
            } 
            else if (location == 2)
            {
                position[0, 1] = xo;
            }
            else if (location == 3)
            {
                position[0, 2] = xo;
            }
            else if (location == 4)
            {
                position[1, 0] = xo;
            }
            else if (location == 5)
            {
                position[1, 1] = xo;
            }
            else if (location == 6)
            {
                position[1, 2] = xo;
            }
            else if (location == 7)
            {
                position[2, 0] = xo;
            }
            else if (location == 8)
            {
                position[2, 1] = xo;
            }
            else if (location == 9)
            {
                position[2, 2] = xo;
            }
        }
        public void printGame()
        {
            for (int rowLoop = 0; rowLoop < 3; rowLoop++)
            {
                for (int colLoop = 0; colLoop < 3; colLoop++)
                {
                    Console.Write("\t" + position[rowLoop, colLoop]);
                }

                Console.WriteLine("\n");
            }
        }
    }
}
