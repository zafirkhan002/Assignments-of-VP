﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            string answer;



            do
            {
                int temp = 0;
                Console.WriteLine("Please remember Location Names \n");
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        
                        Console.Write("\t" + ++temp);
                    }
                    Console.WriteLine("\n");
                }

                Console.WriteLine("\n");

                Game objGame = new Game();

                objGame.Start();

                Console.Write("Press Y if you want to play again : ");
                answer = Console.ReadLine();


            }
            while (answer == "Y" || answer == "y");
            

            
            Console.ReadKey();
        }
    }
}
